package uts.isd.model;

import java.io.Serializable;

/**
 *
 * @author George
 */

public class Movie implements Serializable {

    
    private Integer ID;   
    private String title; 
    private String genere; 
    private Double price;
    private Integer copies;
    private String details;
    
    public Movie(Integer ID, String title, String genere, Double price, Integer copies, String details) {
        this.ID = ID;
        this.title = title;
        this.genere = genere;
        this.price = price;
        this.copies = copies;
        this.details = details;
    
    }
    
    public Integer getID() {
        return ID;
    }
    public String getTitle() {
        return title;
    }
    public String getGenere() {
        return genere;
    }
    public Double getPrice() {
        return price;
    }
    public Integer getCopies() {
        return copies;
    }
    public String getDetails() {
        return details;
    }
}//end class
